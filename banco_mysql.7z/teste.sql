# MySQL-Front 5.0  (Build 1.0)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: teste
# ------------------------------------------------------
# Server version 5.6.19

DROP DATABASE IF EXISTS `teste`;
CREATE DATABASE `teste` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `teste`;

#
# Table structure for table tabela_mestre
#

CREATE TABLE `tabela_mestre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` varchar(255) DEFAULT NULL,
  `data_alteracao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
INSERT INTO `tabela_mestre` VALUES (10,'Teste 4','True','2014-10-06 21:32:11','2014-10-06 21:32:11');
INSERT INTO `tabela_mestre` VALUES (15,'Teste 5','True','2014-10-06 22:16:43','2014-10-06 22:16:43');
INSERT INTO `tabela_mestre` VALUES (16,'teste 6','True','2014-10-06 22:17:20','2014-10-06 22:17:14');
INSERT INTO `tabela_mestre` VALUES (17,'teste 7','True','2014-10-06 22:37:54','2014-10-06 22:37:46');
INSERT INTO `tabela_mestre` VALUES (18,'teste 8 ','True','2014-10-06 22:38:02','2014-10-06 22:38:02');
INSERT INTO `tabela_mestre` VALUES (19,'teste 9','True','2014-10-06 22:38:21','2014-10-06 22:38:21');
/*!40000 ALTER TABLE `tabela_mestre` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table tabela_detalhe
#

CREATE TABLE `tabela_detalhe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mestre` int(11) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` varchar(255) DEFAULT NULL,
  `data_alteracao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `tabela_detalhe` ENABLE KEYS */;
UNLOCK TABLES;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
